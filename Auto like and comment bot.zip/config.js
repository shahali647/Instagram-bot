var config = {
    username : "shoppinghub647",
    password : "shah6652009",
    searchTerm: "#gym",
    comments: ["very good","keep it up", "nice"]
};

module.exports = config;
