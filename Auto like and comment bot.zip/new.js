const puppeteer = require('puppeteer');
const fs = require('fs');

const config = require('./config');
let errorsOccured = 0
var resultsCounter = 0
var jsonData = []
var users = []
var comments = config.comments

var browser

fs.readFile('users.txt', async function (err, data) {
    if (err) throw err;
    const array = await data.toString().split("\n");
    for (user of array) {
        users.push(user)
    }
    signIn()
});

async function signIn() {

    browser = await puppeteer.launch({
        headless: false,
        //args: ['--no-sandbox', '--disable-setuid-sandbox', '--proxy-server=37.48.118.90:13042']
    });

    const page = await browser.newPage();
    await page.goto("https://www.instagram.com/accounts/login/", { timeout: 60 * 1000 });
    await page.waitFor(1 * 1000);
    await page.waitFor('[name=username]');
    await page.type('[name=username]', config.username, { delay: 30 });
    await page.type('[name=password]', config.password, { delay: 30 });
    await page.click('button');
    await page.waitFor("[href='/']");
    await page.click("[href='/']");
    await page.waitFor("body > div:nth-child(14) > div > div._o0j5z > div > div > div > div:nth-child(2)");
    await page.click("body > div:nth-child(14) > div > div._o0j5z > div > div > div > div:nth-child(2)");
    search(page)
};

async function search(page) {
    let url = 'https://www.instagram.com/explore/tags/' + config.searchTerm.replace('#', '')
    await page.goto(url, { timeout: 60 * 1000 });
    await page.click("#react-root > section > main > article > div._21z45 > div > div > div:nth-child(1) > div:nth-child(1) > a > div._e3il2 > div._si7dy");
    comment(page)
}


async function comment(page) {
    await page.waitFor('img');
    await page.click('img');
    loopActions()

    async function loopActions() {
        await page.waitFor(1000);
        await page.waitFor('.notranslate');
        await page.waitFor(1000);

        var nextCheck = await page.evaluate(() => {
            if (document.querySelector('.coreSpriteRightPaginationArrow')) {
                return true
            }
            else {
                return false
            }
        });

        var usernameCheck = await page.evaluate(() => {
            return document.querySelector('.notranslate').title
        });

        console.log(usernameCheck)

        let comment = comments[Math.floor(Math.random() * comments.length)];

        if (users.indexOf(usernameCheck) == -1) {      //user not found in users array/file
            await page.click(".coreSpriteHeartOpen");
            await page.type('[placeholder = "Add a comment…"]', comment, { delay: 30 });
            await page.keyboard.down(String.fromCharCode(13));
            users.push(usernameCheck)
            addUserToFile(usernameCheck)
            await page.waitFor(3000);
            await page.click('.coreSpriteRightPaginationArrow');
            loopActions()
        }
        else if (nextCheck) {
            console.log('Already commented for this user')
            await page.click('.coreSpriteRightPaginationArrow');
            loopActions()
        }
        else {
            console.log('Results finished, searching again')
            search(page)
        }
    }


    async function loopResults(page) {
        await page.waitFor('img');
        await page.click('img');
        loopActions()

        async function loopActions() {
            await page.waitFor(1000);
            await page.waitFor('.notranslate');
            await page.waitFor(1000);
            var usernameCheck = await page.evaluate(() => {
                return document.querySelector('.notranslate').title
            });

            console.log(usernameCheck)
            if (jsonData.length == 0 || jsonData.filter(e => e.username == usernameCheck).length == 0) {

                await page.click('.notranslate');
                console.log("clicked next image")
                await page.waitFor(4000);
                var pageData = await page.evaluate(() => {
                    let name = "N/A"
                    let username = document.querySelector('.notranslate').title
                    let posts = document.querySelectorAll('ul li span')[1].innerText
                    let followers = document.querySelectorAll('ul li span')[2].title
                    let bio = document.querySelectorAll('div > span ')[1].innerText
                    if (document.querySelectorAll('h1')[1]) {
                        name = document.querySelectorAll('h1')[1].innerText
                    }
                    return {
                        username: username,
                        posts: posts,
                        followers: followers,
                        bio: bio,
                        name: name
                    }
                });
                //console.log(pageData)
                checkAndSave(pageData)
                var goBack = await page.evaluate(() => {
                    history.back()
                    return 1
                });
                var nextCheck = await page.evaluate(() => {
                    if (document.querySelector('.coreSpriteRightPaginationArrow')) {
                        return true
                    }
                    else {
                        return false
                    }
                });
                //console.log(nextCheck)
                if (nextCheck && resultsCounter < config.csvFileLimit) {
                    await page.click('.coreSpriteRightPaginationArrow');
                    loopActions()
                }
                else {
                    saveToCSV()
                }

            }
            else {
                console.log("Already Checked this profile, Skipping!")
                var nextCheck = await page.evaluate(() => {
                    if (document.querySelector('.coreSpriteRightPaginationArrow')) {
                        return true
                    }
                    else {
                        return false
                    }
                });
                //console.log(nextCheck)
                if (nextCheck && resultsCounter <= config.csvFileLimit) {
                    await page.click('.coreSpriteRightPaginationArrow');
                    loopActions()
                }
                else {
                    saveToCSV()
                }
            }
        }

    }

    async function checkAndSave(data) {
        let email = await extractEmails(data.bio)

        let posts = parseFloat(data.posts.replace(/,/g, ''));
        let followers = parseFloat(data.followers.replace(/,/g, ''));

        let ratio = posts / followers * 100


        if (email == null) {
            email = "N/A"
        }
        else if (ratio >= config.Ratio) {
            resultsCounter++
            jsonData.push({
                username: data.username,
            })
            ["UserName", "Followers", "Posts", "Ratio", "Email"]

            let csvrow = []
            csvrow.push(data.username)
            csvrow.push(data.name)
            csvrow.push(data.followers)
            csvrow.push(data.posts)
            csvrow.push(Math.round(ratio))
            csvrow.push(email)

            writer.write(csvrow);
            console.log(csvrow)
        }
        else {
            console.log("Ratio not good:", ratio)
        }

        //console.log(data, email,ratio)

    }

    function extractEmails(text) {
        return text.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
    }

    async function saveToCSV() {
        console.log("No more results or Limit reached, saving data", jsonData)
        console.log('End');

        writer.end();
        await browser.close();
    }

    function links() {

        fs.readFile('test.txt', function (err, data) {

            if (err) throw err;

            const array = data.toString().split("\n");

            run(array);

            //test(array)
        });

    }


    function errors(link) {

        var stream = fs.createWriteStream("errors.txt", { 'flags': 'a' });

        stream.once('open', function (fd) {

            stream.write(link + "\n");

            stream.end();

        });

    }
}

function addUserToFile(user) {
    var stream = fs.createWriteStream("users.txt", { 'flags': 'a' });
    stream.once('open', function (fd) {
        stream.write(user + "\n");
        stream.end();
    });
}