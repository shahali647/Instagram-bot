const puppeteer = require('puppeteer');
const fs = require('fs');

const config = require('./config');
let errorsOccured = 0
var csvWriter = require('csv-write-stream')
var resultsCounter = 0
var jsonData = []
var users = []
var comments = config.comments

var browser

fs.readFile('users.txt', async function (err, data) {
    if (err) throw err;
    const array = await data.toString().split("\n");
    for (user of array){
        users.push(user)
    }
    signIn()
});
writer = csvWriter({ headers: ["UserName","Name","Followers","Posts","Ratio","Email"]});
var browser


async function signIn() {

    browser = await puppeteer.launch({
        headless: false,
        //args: ['--no-sandbox', '--disable-setuid-sandbox', '--proxy-server=37.48.118.90:13042']
    });

    const page = await browser.newPage();
    await page.goto("https://www.instagram.com/accounts/login/", { timeout: 60 * 1000 });
    await page.waitFor(1 * 1000);
    await page.waitFor('[name=username]');
    await page.type('[name=username]', config.username, { delay: 30 });
    await page.type('[name=password]', config.password, { delay: 30 });
    await page.click('button');
    await page.waitFor("[href='/']");
    await page.click("[href='/']");
    search(page)
};


async function search(page) {
    let url = 'https://www.instagram.com/explore/tags/' +  config.searchTerm.replace('#','')
    await page.goto( url, { timeout: 60 * 1000 });
    comment(page)
}




async function comment(page) {
    await page.waitFor('img');
    await page.click('img');
    loopActions()


    async function loopActions() {
        await page.waitFor(1000);
        await page.waitFor('.notranslate');
        await page.waitFor(1000);
        await page.click('header .notranslate');


       

        var usernameCheck = await page.evaluate(() => {
            return document.querySelector('.notranslate').title
        });

        


        if (users.indexOf(usernameCheck)== -1) {

            
            console.log("clicked next image")
            await page.waitFor(4000);
            var pageData = await page.evaluate(() => {
                let name = "N/A"
                let username = document.querySelector('.notranslate').title
                let posts = document.querySelectorAll('ul li span')[1].innerText
                let followers = document.querySelectorAll('ul li span')[2].title
                let bio = document.querySelectorAll('div > span ')[1].innerText
                if(document.querySelectorAll('h1')[1]){
                    name = document.querySelectorAll('h1')[1].innerText
                }
                return {
                    username: username,
                    posts: posts,
                    followers: followers,
                    bio: bio,
                    name:name
                }
            });
            //console.log(pageData)
            //checkAndSave(pageData)
            let posts = parseFloat(pageData.posts.replace(/,/g, ''));
            let followers = parseFloat(pageData.followers.replace(/,/g, ''));
        
            //let ratio = posts/followers * 100
        
            var goBack = await page.evaluate(() => {
                history.back()
                return 1
            });
        
            
             if(posts > 30 && followers > 100){
                
                await page.click('button');
                await page.waitFor(10000);
                addUserToFile(pageData.username)
                //console.log('ratio was good ratio =')
                resultsCounter++
                // jsonData.push({
                //     username: pageData.username,
                // })
            }
            else{
                console.log("Ratio not good:")
            }



            var nextCheck = await page.evaluate(() => {
                if (document.querySelector('.coreSpriteRightPaginationArrow')) {
                    return true
                }
                else {
                    return false
                }
            });
            //console.log(nextCheck)
            if (nextCheck) {
                await page.click('.coreSpriteRightPaginationArrow');
                loopActions()
            }
            else {
                saveToCSV()
            }

        }
        else{
            console.log("Already Checked this profile, Skipping!")
            var nextCheck = await page.evaluate(() => {
                if (document.querySelector('.coreSpriteRightPaginationArrow')) {
                    return true
                }
                else {
                    return false
                }
            });
            //console.log(nextCheck)
            if (nextCheck) {
                await page.click('.coreSpriteRightPaginationArrow');
                loopActions()
            }
            else {
                saveToCSV()
            }
        }
    }

}

async function checkAndSave(data) {
    let email = await extractEmails(data.bio)
    
    let posts = parseFloat(data.posts.replace(/,/g, ''));
    let followers = parseFloat(data.followers.replace(/,/g, ''));

    let ratio = posts/followers * 100


    
     if(ratio >= config.Ratio){
        await page.click('button');
        resultsCounter++
        jsonData.push({
            username: data.username,
        })
        ["UserName","Followers","Posts","Ratio","Email"]

        let csvrow = []
        csvrow.push(data.username)
        csvrow.push(data.name)
        csvrow.push(data.followers)
        csvrow.push(data.posts)
        csvrow.push(Math.round(ratio))
        csvrow.push(email)

        writer.write(csvrow);
        console.log(csvrow)
    }
    else{
        console.log("Ratio not good:",ratio)
    }

    //console.log(data, email,ratio)

}

function extractEmails(text) {
    return text.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
}

async function saveToCSV() {
    console.log("No more results or Limit reached, saving data", jsonData)
    console.log('End');

    writer.end();
    await browser.close();
}

function links() {

    fs.readFile('test.txt', function (err, data) {

        if (err) throw err;

        const array = data.toString().split("\n");

        run(array);

        //test(array)
    });

}


function errors(link) {

    var stream = fs.createWriteStream("errors.txt", { 'flags': 'a' });

    stream.once('open', function (fd) {

        stream.write(link + "\n");

        stream.end();

    });

}
function addUserToFile(user){
    var stream = fs.createWriteStream("users.txt", { 'flags': 'a' });
    stream.once('open', function (fd) {
        stream.write(user + "\n");
      stream.end();
    });
 }