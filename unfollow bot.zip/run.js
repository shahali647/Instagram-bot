const puppeteer = require('puppeteer');
const fs = require('fs');

const config = require('./config');
let errorsOccured = 0
var resultsCounter = 0
var jsonData = []
var users = []
var comments = config.comments

var browser

// fs.readFile('users.txt', async function (err, data) {
//     if (err) throw err;
//     const array = await data.toString().split("\n");
//     for (user of array){
//         users.push(user)
//     }
//     signIn()
// });
//writer = csvWriter({ headers: ["UserName","Name","Followers","Posts","Ratio","Email"]});
var browser

signIn()
async function signIn() {

    browser = await puppeteer.launch({
        headless: false,
        //args: ['--no-sandbox', '--disable-setuid-sandbox', '--proxy-server=37.48.118.90:13042']
    });

    const page = await browser.newPage();
    await page.goto("https://www.instagram.com/accounts/login/", { timeout: 60 * 1000 });
    await page.waitFor(1 * 1000);
    await page.waitFor('[name=username]');
    await page.type('[name=username]', config.username, { delay: 30 });
    await page.type('[name=password]', config.password, { delay: 30 });
    await page.click('button');
    await page.waitFor("[href='/']");
    await page.click("[href='/']");
    search(page)
};



    

async function search(page) {
    await page.waitFor("[href='/shoppinghub647/']");
    await page.click("[href='/shoppinghub647/']");

    //await page.waitFor(1 * 1000);

    await page.waitFor("[href='/shoppinghub647/following/']");
    await page.click("[href='/shoppinghub647/following/']");
    await page.waitFor(1 * 3000);
    unfollowLoop(page)
}


//let followingLength = document.querySelector('#react-root > section > main > article > header > section > ul > li:nth-child(3) > a').innerText.replace('following','')
 
async function unfollowLoop(page){
let followingLength = 200



for (let i = 1; i <= followingLength; i++) {
     let selector = 'div._gs38e > ul > div > li:nth-child(index) > div > div._mtnzs > span > button'
    
     selector = selector.replace('index',i)

    await page.click(selector);
    await page.waitFor(1 * 15000);
    
}
}